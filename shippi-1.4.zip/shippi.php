<?php
/**
 * Plugin Name: Shippi
 * Description: API WooCommerce Plugin for Orders and Shipping Functionality | Still In Development Phase
 * Version: 1.4
 * Author: CSLoyD
 */

require_once plugin_dir_path(__FILE__) . 'constants.php';
require_once plugin_dir_path(__FILE__) . 'install.php';


require_once plugin_dir_path(__FILE__) . 'token_validation.php';
require_once plugin_dir_path(__FILE__) . 'orders_shipping_func.php';


function my_plugin_update_check() {
    
    $update_url = 'https://raw.githubusercontent.com/CSLoyD/wikis/refs/heads/master/shippi-update.json';
    $plugin_slug = basename(__FILE__, '.php'); 

    $response = wp_remote_get($update_url);
    if (is_wp_error($response)) {
        return;
    }

    $response_body = wp_remote_retrieve_body($response);
    $update_info = json_decode($response_body);

    
    $plugin_data = get_plugin_data(__FILE__);
    if (version_compare($plugin_data['Version'], $update_info->new_version, '<')) {
        $plugin_transient = (object) [
            'slug'        => $plugin_slug,
            'new_version' => $update_info->new_version,
            'package'     => $update_info->package,
            'tested'      => $update_info->tested,
            'requires'    => $update_info->requires
        ];
        set_site_transient('update_plugins', (object) ['response' => [$plugin_slug => $plugin_transient]]);
    }
}

add_filter('pre_set_site_transient_update_plugins', 'my_plugin_update_check');


