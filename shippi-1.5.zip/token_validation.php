<?php
// File: token_validation.php

function validate_api_token($request) {
    global $wpdb;
    $token = $request->get_header('shippi-api-key');
    $table_name = $wpdb->prefix . 'shippi_api_tokens';

    $stored_token = $wpdb->get_var($wpdb->prepare(
        "SELECT token FROM $table_name WHERE token = %s",
        $token
    ));

    if ($stored_token) {
        return true;
    } else {
        return new WP_Error('invalid_token', 'Invalid API Token', array('status' => 403));
    }
}

add_action('admin_menu', 'register_api_token_menu');

function register_api_token_menu() {
    add_menu_page(
        'API Tokens',
        'API Tokens',
        'manage_options',
        'api-tokens',
        'api_token_management_page',
        'dashicons-admin-network',
        20
    );
}

function api_token_management_page() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'shippi_api_tokens';

    if (isset($_POST['generate_token'])) {
        $new_token = wp_generate_password(32, false);
        $wpdb->insert($table_name, array('token' => $new_token));
        echo "<div class='updated'><p>New token generated: <strong>$new_token</strong></p></div>";
    }

    if (isset($_POST['delete_token'])) {
        $token_id = intval($_POST['token_id']);
        $wpdb->delete($table_name, array('id' => $token_id));
        echo "<div class='updated'><p>Token deleted.</p></div>";
    }

    $tokens = $wpdb->get_results("SELECT * FROM $table_name");

    echo '<div class="wrap">';
    echo '<h1>API Token Management</h1>';

    echo '<form method="post">';
    submit_button('Generate New Token', 'primary', 'generate_token');
    echo '</form>';

    if ($tokens) {
        echo '<h2>Existing Tokens</h2>';
        echo '<table class="widefat">';
        echo '<thead><tr><th>ID</th><th>Token</th><th>Created At</th><th>Action</th></tr></thead>';
        echo '<tbody>';
        foreach ($tokens as $token) {
            echo '<tr>';
            echo '<td>' . esc_html($token->id) . '</td>';
            echo '<td><input type="text" id="token_' . esc_attr($token->id) . '" value="' . esc_html($token->token) . '" readonly style="width: 100%; cursor: pointer;" class="copyable-token"></td>';
            echo '<td>' . esc_html($token->created_at) . '</td>';
            echo '<td><form method="post"><input type="hidden" name="token_id" value="' . esc_attr($token->id) . '"/>';
            submit_button('Delete', 'delete', 'delete_token', false);
            echo '</form></td>';
            echo '</tr>';
        }
        echo '</tbody>';
        echo '</table>';
    } else {
        echo '<p>No tokens available.</p>';
    }

    echo '</div>';

    echo '<script>
        document.addEventListener("DOMContentLoaded", function() {
            const tokenInputs = document.querySelectorAll(".copyable-token");

            tokenInputs.forEach(tokenInput => {
                tokenInput.addEventListener("click", function() {
                    tokenInput.select();
                    tokenInput.setSelectionRange(0, 99999); // For mobile devices
                    document.execCommand("copy");
                    alert("Token copied: " + tokenInput.value);
                });
            });
        });
    </script>';
}


