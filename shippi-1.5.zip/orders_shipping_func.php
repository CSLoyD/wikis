<?php
// File: orders_shipping_func.php

add_action('rest_api_init', function () {
    
    // For Fetching Orders
    register_rest_route('shippi/'.SHIPPI_VERSION, '/orders', array(
        'methods' => 'GET',
        'callback' => 'fetch_woocommerce_orders',
        'permission_callback' => '__return_true'
    ));

    // For Updating Order
    register_rest_route('shippi/'.SHIPPI_VERSION, '/orders/update', array(
        'methods' => 'POST',
        'callback' => 'update_order',
        'args' => array(
            'order_id' => array(
                'required' => true,
                'validate_callback' => function ($param, $request, $key) {
                    return is_numeric($param);
                }
            ),
            'status' => array(
                'required' => true,
                'validate_callback' => function ($param, $request, $key) {
                    return is_string($param);
                }
            ),
            'billing' => array(
                'required' => false,
                'validate_callback' => function ($param, $request, $key) {
                    return is_array($param);
                }
            ),
            'shipping' => array(
                'required' => false,
                'validate_callback' => function ($param, $request, $key) {
                    return is_array($param);
                }
            ),
            'custom_fields' => array(
                'required' => false,
                'validate_callback' => function ($param, $request, $key) {
                    return is_array($param);
                }
            ),
        ),
        'permission_callback' => '__return_true'
    ));

    // Sending Order Details to Customer
    register_rest_route('shippi/'.SHIPPI_VERSION, '/orders/send-details', array(
        'methods' => 'POST',
        'callback' => 'send_order_details_to_customer',
        'args' => array(
            'order_id' => array(
                'required' => true,
                'validate_callback' => function ($param, $request, $key) {
                    return is_numeric($param);
                }
            )
        ),
        'permission_callback' => '__return_true'
    ));

    // For Shipping - Add Shipping Zone
    register_rest_route('shippi/'.SHIPPI_VERSION, '/shipping/zone/add', array(
        'methods' => 'POST',
        'callback' => 'add_shipping_zone',
        'args' => array(
            'zone_name' => array(
                'required' => true,
                'validate_callback' => function ($param, $request, $key) {
                    return is_string($param);
                }
            ),
            'regions' => array(
                'required' => true,
                'validate_callback' => function ($param, $request, $key) {
                    return is_array($param);
                }
            ),
        ),
        'permission_callback' => '__return_true'
    ));

    // For Shipping - Add Shipping Method
    register_rest_route('shippi/'.SHIPPI_VERSION, '/shipping/method/add', array(
        'methods' => 'POST',
        'callback' => 'add_shipping_method_to_zone',
        'args' => array(
            'zone_id' => array(
                'required' => true,
                'validate_callback' => function ($param, $request, $key) {
                    return is_numeric($param);
                }
            ),
            'method_name' => array(
                'required' => true,
                'validate_callback' => function ($param, $request, $key) {
                    return is_string($param);
                }
            ),
            'cost' => array(
                'required' => false,
                'validate_callback' => function ($param, $request, $key) {
                    return is_numeric($param);
                }
            ),
        ),
        'permission_callback' => '__return_true'
    ));

});

// Get Orders
function fetch_woocommerce_orders($data) {
    if (!class_exists('WooCommerce')) {
        return new WP_Error('woocommerce_not_found', 'WooCommerce is not installed or activated.', array('status' => 404));
    }

    $token_validation = validate_api_token($data);
    if (is_wp_error($token_validation)) {
        return $token_validation;
    }

    $args = array(
        'status' => isset($data['status']) ? sanitize_text_field($data['status']) : 'any',
        'limit' => isset($data['limit']) ? (int) sanitize_text_field($data['limit']) : 10,
    );

    $orders = wc_get_orders($args);

    if (empty($orders)) {
        return new WP_Error('no_orders', 'No orders found.', array('status' => 404));
    }

    $formatted_orders = array();

    foreach ($orders as $order) {
        $formatted_orders[] = array(
            'id' => $order->get_id(),
            'status' => $order->get_status(),
            'total' => $order->get_total(),
            'billing' => $order->get_address('billing'),
            'shipping' => $order->get_address('shipping'),
        );
    }

    return $formatted_orders;
}

function update_order($data) {
    if (!class_exists('WooCommerce')) {
        return new WP_Error('woocommerce_not_found', 'WooCommerce is not installed or activated.', array('status' => 404));
    }

    $token_validation = validate_api_token($data);
    if (is_wp_error($token_validation)) {
        return $token_validation;
    }

    $order_id = (int) $data['order_id'];
    $new_status = sanitize_text_field($data['status']);
    
    $order = wc_get_order($order_id);
    if (!$order) {
        return new WP_Error('invalid_order', 'Order not found.', array('status' => 404));
    }

    $valid_statuses = wc_get_order_statuses(); 
    $new_status_key = 'wc-' . $new_status;

    if (array_key_exists($new_status_key, $valid_statuses)) {
        $order->update_status($new_status);
    } else {
        return new WP_Error('invalid_status', 'Invalid order status.', array('status' => 400));
    }

    if (!empty($data['billing'])) {
        $billing_data = array_map('sanitize_text_field', $data['billing']);
        $order->set_address($billing_data, 'billing');
    }

    if (!empty($data['shipping'])) {
        $shipping_data = array_map('sanitize_text_field', $data['shipping']);
        $order->set_address($shipping_data, 'shipping');
    }

    if (!empty($data['custom_fields'])) {
        foreach ($data['custom_fields'] as $key => $value) {
            $order->update_meta_data(sanitize_text_field($key), sanitize_text_field($value));
        }
    }

    $order->save();

    if (isset($data['send_details']) && $data['send_details'] === true) {
        send_order_details_to_customer(array('order_id' => $order_id));
    }

    return array('message' => 'Order updated successfully.');
}

function send_order_details_to_customer($data) {
    if (!class_exists('WooCommerce')) {
        return new WP_Error('woocommerce_not_found', 'WooCommerce is not installed or activated.', array('status' => 404));
    }

    $token_validation = validate_api_token($data);
    if (is_wp_error($token_validation)) {
        return $token_validation;
    }

    $order_id = (int) $data['order_id'];

    $order = wc_get_order($order_id);
    if (!$order) {
        return new WP_Error('invalid_order', 'Order not found.', array('status' => 404));
    }

    wc_send_order_details($order);

    return array('message' => 'Order details sent successfully to ' . $order->get_billing_email());
}

function wc_send_order_details($order) {
    $mailer = WC()->mailer();
    
    $mailer->emails['WC_Email_Customer_Processing_Order']->trigger($order->get_id(), $order);

    return true;
}


function add_shipping_zone($data) {
    if (!class_exists('WooCommerce')) {
        return new WP_Error('woocommerce_not_found', 'WooCommerce is not installed or activated.', array('status' => 404));
    }

    $token_validation = validate_api_token($data);
    if (is_wp_error($token_validation)) {
        return $token_validation;
    }

    $zone = new WC_Shipping_Zone();
    $zone->set_zone_name(sanitize_text_field($data['zone_name']));
    $zone->set_zone_locations(array());

    foreach ($data['regions'] as $region) {
        if (is_string($region)) {
            $zone->add_location($region, 'country');
        }
    }

    $zone_id = $zone->save();

    if (!$zone_id) {
        return new WP_Error('failed_to_create_zone', 'Could not create shipping zone.', array('status' => 500));
    }

    return array('message' => 'Shipping zone created successfully', 'zone_id' => $zone_id);
}

function add_shipping_method_to_zone($data) {
    if (!class_exists('WooCommerce')) {
        return new WP_Error('woocommerce_not_found', 'WooCommerce is not installed or activated.', array('status' => 404));
    }

    $token_validation = validate_api_token($data);
    if (is_wp_error($token_validation)) {
        return $token_validation;
    }

    $zone_id = (int) $data['zone_id'];
    $method_id = sanitize_text_field($data['method_name']);
    $cost = isset($data['cost']) ? (float) $data['cost'] : 0;

    
    $zone = new WC_Shipping_Zone($zone_id);
    if (!$zone->get_id()) {
        return new WP_Error('invalid_zone', 'Shipping zone not found.', array('status' => 404));
    }

    $methods = $zone->get_shipping_methods();
    foreach ($methods as $method) {
        if ($method->id === $method_id) {
            return new WP_Error('method_exists', 'Shipping method already exists for this zone.', array('status' => 400));
        }
    }
    
    $result = $zone->add_shipping_method($method_id);

    if ($result && $method_id === 'flat_rate') {
        $shipping_methods = $zone->get_shipping_methods();
        foreach ($shipping_methods as $shipping_method) {
            if ($shipping_method->method_id === 'flat_rate') {
                $instance_id = $shipping_method->instance_id;
                break;
            }
        }

        if (isset($instance_id)) {
            update_option('woocommerce_flat_rate_' . $instance_id . '_settings', array(
                'title' => 'Flat Rate',
                'cost' => $cost,
                'tax_status' => 'taxable'
            ));
        }
    }

    return array('message' => 'Shipping method added successfully', 'method_id' => $method_id);
}