<?php
// File: constants.php

define('SHIPPI_VERSION', 'v1');